#!/usr/bin/python
# -*- coding: utf-8 -*-
import httplib,urllib2,json,sys
from scapy.all import *

end = '\033[0m'
red = '\033[1;31m'
bright_green = '\033[1;32m'
bright_yellow = '\033[1;33m'

def final():
    import nelson as n
    n.main()

def get_ccr(target):
    try:
        response = urllib2.urlopen("http://ip-api.com/json/%s"%(target))
    except (httplib.BadStatusLine,urllib2.URLError,socket.timeout):
        print("[%s-%s] Connessione a internet non riuscita"%(red,end))
        final()
    except KeyboardInterrupt:
        print("\n[%s-%s] Interrotto\n"%(red,end))
        final()
    try:
        data = response.read()
        values = json.loads(data)
    except KeyboardInterrupt:
        print("\n[%s-%s] Interrotto\n"%(red,end))
        final()
    try:
        countrycode = values['countryCode']
    except KeyError:
        countrycode = ""
    try:
        region = values['region']
    except KeyError:
        region = ""
    results = "(%s-%s)"%(countrycode,region)
    if region == "" or countrycode == "":
        results = "(  -  )"
    return results

def trace(target):
    print("[%s*%s] Avvio...\n"%(bright_yellow,end))
    for i in range(1, 28):
        try:
            results = 0
            pkt = IP(dst=target, ttl=i) / UDP(dport=33434)
            reply = sr1(pkt, verbose=0) # Spedisce il pacchetto e riceve una risposta
            if reply is None:
                print("\r  \n[%s-%s] Terminato\n"%(red,end))
                final()
            elif reply.type == 3:
                if results == 0:
                    print("[%s-%s] Nessun risultato"%(red,end))
                print("[%s*%s] Terminato\n"%(bright_yellow,end))
                final()
            else:
                try:
                    hostname = socket.gethostbyaddr(reply.src)[0]
                except socket.herror: # parrot os
                    hostname = socket.getfqdn(reply.src)
                    if hostname == reply.src:
                        hostname = "( None )"
                hostname = "> " + hostname
                results += 1
                print("[%s+%s] %s %s %s"%(bright_green,end, reply.src, get_ccr(reply.src), hostname))
        except socket.gaierror:
            print("[%s-%s] Indirizzo sconosciuto\n"%(red,end))
            final()
