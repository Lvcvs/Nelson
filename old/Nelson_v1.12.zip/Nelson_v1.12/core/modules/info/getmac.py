#!/usr/bin/python
# -*- coding: utf-8 -*-
from subprocess import Popen, PIPE
import subprocess,os
import re

end = '\033[0m'
red = '\033[1;31m'
bright_green = '\033[1;32m'
bright_yellow = '\033[1;33m'

def final():
    import nelson as n
    n.main()

def getmac(ip):
    DEVNULL = open(os.devnull, "wb")
    if "http://" in ip:
        ip = ip.replace("http://","")
    if "https://" in ip:
        ip = ip.replace("https://","")
    pid = Popen(["arp", "-n", ip], stdout=PIPE, stderr=DEVNULL)
    s = pid.communicate()[0]
    try:
        mac = re.search(r"(([a-f\d]{1,2}\:){5}[a-f\d]{1,2})", s).groups()[0]
    except AttributeError:
        print("[%s-%s] %s \t>> ( - )"%(red,end, ip))
        final()
    print("[%s+%s] %s \t>> %s"%(bright_green,end, ip, mac))
