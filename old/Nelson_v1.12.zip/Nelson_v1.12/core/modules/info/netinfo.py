#!/usr/bin/python
# -*- coding: utf-8 -*-
import os,socket,re,uuid,struct,netifaces,requests,sys
reload(sys)
sys.setdefaultencoding('utf8')

end = '\033[0m'
red = '\033[1;31m'
underline = '\033[4m'

def printtle(text):
    print(u"\u250C"+2*u"\u2500"+text)
def printinf(text):
    print("%s # %s"%(u"\u251C"+u"\u257C",text))
def printlst(text):
    print("%s # %s"%(u"\u2514"+u"\u257C",text))

def final():
    import nelson as n
    n.main()

def get_gateway():
    with open("/proc/net/route") as fh:
        for line in fh:
            fields = line.strip().split()
            if fields[1] != '00000000' or not int(fields[3], 16) & 2: continue
            return socket.inet_ntoa(struct.pack("<L", int(fields[2], 16)))

def netinfo():
    try:
        localip = [l for l in ([ip for ip in socket.gethostbyname_ex(socket.gethostname())[2] if not ip.startswith("127.")][:1], [[(s.connect(('8.8.8.8', 53)), s.getsockname()[0], s.close()) for s in [socket.socket(socket.AF_INET, socket.SOCK_DGRAM)]][0][1]]) if l][0][0]
    except (socket.herror,socket.gaierror): # parrot os
        iface = netifaces.gateways()['default'][netifaces.AF_INET][1]
        localip = netifaces.ifaddresses(str(iface))[netifaces.AF_INET][0]['addr']
    except socket.error:
        localip = "-"
    try:
        publicip = requests.get('http://ip.42.pl/raw').text
    except requests.exceptions.ConnectionError:
        publicip = "-"
    except KeyboardInterrupt:
        print("\n[%s-%s] Interrotto\n"%(red,end))
        final()
    try:
        iface = netifaces.gateways()['default'][netifaces.AF_INET][1]
    except KeyError:
        iface = "-"
    mac_permanent = ':'.join(re.findall('..', '%012x' % uuid.getnode()))
    print("")
    established = "netstat -natu | grep 'ESTABLISHED'"
    results = os.popen(established).read().splitlines()
    processing = []
    for e in results:
        e = e.replace("ESTABLISHED","")
        e = e.split()
        if "tcp6" in e or "udp6" in e:
            pass
        else:
            processing.append(e)
    results = []
    for e in processing:
        results.append(e)
    printtle("[ %sConnessioni stabilite%s ]"%(underline,end))
    if len(results) == 0:
        printinf("Nessuna connessione stabilita")
    else:
        for e in results:
            printinf("%s >> %s\t >> %s"%(e[0],e[3],e[4]))
    try:
        l_host = socket.gethostbyaddr(localip)[0]
    except socket.herror: # parrot os
        l_host = socket.getfqdn(localip)
    try:
        p_host = socket.gethostbyaddr(publicip)[0]
    except (socket.herror,socket.gaierror): # parrot os
        p_host = socket.getfqdn(publicip)
    if l_host == localip:
        l_host = "-"
    if p_host == publicip:
        p_host = "-"
    print(u"\u2502")
    print("%s[ %sInformazioni di rete%s ]"%(u"\u251C"+2*u"\u2500",underline,end))
    printinf("Interfaccia         >> %s"%(iface))
    printinf("Gateway             >> %s"%(str(get_gateway())))
    printinf("IP Locale           >> %s"%(localip))
    printinf("IP Pubblico         >> %s"%(publicip))
    printinf("Mac (Permanent)     >> %s"%(mac_permanent))
    printinf("Hostname (Locale)   >> %s"%(l_host))
    printlst("Hostname (Pubblico) >> %s\n"%(p_host))
