#!/usr/bin/python
# -*- coding: utf-8 -*-
import socket,urllib2,json,httplib,sys
import socks
reload(sys)
sys.setdefaultencoding('utf8')

end = '\033[0m'
red = '\033[1;31m'
underline = '\033[4m'

def final():
    import nelson as n
    n.main()

def printtle(text):
    print(u"\u250C"+2*u"\u2500"+text)
def printinf(text):
    print("%s # %s"%(u"\u251C"+u"\u257C",text))
def printlst(text):
    print("%s # %s"%(u"\u2514"+u"\u257C",text))

def whois(target):
    socket.setdefaulttimeout(3)
    if "http://" in target:
        target = target.replace("http://","")
    if "https://" in target:
        target = target.replace("https://","")
    try:
        getip = socket.gethostbyname("%s"%(target))
    except socket.gaierror:
        print("[%s-%s] Indirizzo sconosciuto"%(red,end))
        return final()
    try:
        response = urllib2.urlopen("http://ip-api.com/json/%s"%(getip))
    except (httplib.BadStatusLine,urllib2.URLError,socket.timeout):
        print("[%s-%s] Richiesta scaduta"%(red,end))
        final()
    except KeyboardInterrupt:
        print("\n[%s-%s] Interrotto\n"%(red,end))
        final()
    try:
        data = response.read()
        values = json.loads(data)
        ip = getip
        socket.inet_aton(ip)
        hostname = socket.getfqdn(ip)
    except KeyboardInterrupt:
        print("\n[%s-%s] Interrotto\n"%(red,end))
        final()
    if hostname == ip:
        hostname = ""
    try:
        country = values['country']
    except KeyError:
        country = ""
    try:
        countrycode = values['countryCode']
        countrycode = "(%s)"%(countrycode)
    except KeyError:
        countrycode = ""
    try:
        region_name = values['regionName']
    except KeyError:
        region_name = ""
    try:
        region = values['region']
        region = "(%s)"%(region)
    except KeyError:
        region = ""
    try:
        city = values['city']
    except KeyError:
        city = ""
    try:
        zip_code = values['zip']
    except KeyError:
        zip_code = ""
    try:
        isp = values['isp']
    except KeyError:
        isp = ""
    try:
        org = values['org']
    except KeyError:
        org = ""
    try:
        gestore = values['as']
    except KeyError:
        gestore = ""
    try:
        lat_lon = str(values['lat']) + " / " + str(values['lon'])
    except KeyError:
        lat_lon = ""
    try:
        timezone = values['timezone']
    except KeyError:
        timezone = ""
    print("")
    printtle("[ %sWhois%s ]"%(underline,end))
    printinf("IP        > %s "%(ip))
    printinf("Hostname  > %s"%(hostname))
    printinf("Nazione   > %s %s"%(country, countrycode))
    printinf("Regione   > %s %s"%(region_name, region))
    printinf("C.Postale > %s"%(zip_code))
    printinf("Citta'    > %s"%(city))
    printinf("Provider  > %s"%(isp))
    printinf("Organizz. > %s"%(org))
    printinf("Gestore   > %s"%(gestore))
    printinf("Lat/Long  > %s"%(lat_lon))
    printlst("F.Orario  > %s"%(timezone))
