#!/usr/bin/python
# -*- coding: utf-8 -*-
import bluetooth,time,os
from datetime import datetime

end = '\033[0m'
red = '\033[1;31m'
bright_green = '\033[1;32m'
bright_yellow = '\033[1;33m'

def final():
    import nelson as n
    n.main()

def scan():
    s_time = datetime.now().strftime('%H:%M:%S')
    print("\n[%s*%s] Avvio scansione bluetooth: %s"%(bright_yellow,end, s_time))
    start_ = time.time()
    try:
        nearby_devices = bluetooth.discover_devices(lookup_names=True)
    except OSError:
        print("[%s-%s] Interfaccia bluetooth non trovata\n"%(red,end))
        final()
    print("")
    if len(nearby_devices) == 1:
        syntax = "o"
    else:
        syntax = "i"
    print("\n[%s*%s] Dispositiv%s trovat%s: %s \n"%(bright_yellow,end ,syntax,syntax, len(nearby_devices)))
    for addr, name in nearby_devices:
        print("[%s+%s] %s \t>> %s"%(bright_green,end, addr, name))
    end_ = time.time()
    elapsed = round((end_-start_), 2)
    e_time = datetime.now().strftime('%H:%M:%S')
    print("\n[%s*%s] Scansione terminata [ %s ]\n[%s*%s] Durata: %s secondi\n"%(bright_yellow,end, e_time, bright_yellow,end, elapsed))
