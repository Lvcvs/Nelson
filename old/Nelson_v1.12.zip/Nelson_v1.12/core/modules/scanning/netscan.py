#!/usr/bin/python
# -*- coding: utf-8 -*-
import socket,os,multiprocessing,subprocess,time,sys,netifaces,re,uuid
from datetime import datetime
from subprocess import Popen, PIPE

end = '\033[0m'
red = '\033[1;31m'
bright_green = '\033[1;32m'
bright_yellow = '\033[1;33m'

def final():
    import nelson as n
    n.main()

def pinger(job_q, results_q):
    DEVNULL = open(os.devnull, 'w')
    while True:
        ip = job_q.get()
        if ip is None:
            break
        try:
            subprocess.check_call(['ping', '-c1', ip], stdout=DEVNULL, stderr=DEVNULL)
            results_q.put(ip)
        except:
            pass

def get_my_ip():
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        s.connect(("8.8.8.8", 80))
    except socket.error:
        print("\n[%s-%s] Nessuna connessione\n"%(red,end))
        final()
    ip = s.getsockname()[0]
    s.close()
    return ip

def progress(count, total):
    percents = round(100.0 * count / float(total), 1)
    sys.stdout.write('{}% '.format(percents))
    sys.stdout.flush()

def map_network(pool_size=255):
    def mute():
        sys.stdout = open(os.devnull, "w") # muta output multiprocessing
    ip_list = list()
    ip_parts = get_my_ip().split('.')
    base_ip = ip_parts[0] + '.' + ip_parts[1] + '.' + ip_parts[2] + '.'
    jobs = multiprocessing.Queue()
    results = multiprocessing.Queue()
    pool = [multiprocessing.Process(target=pinger, args=(jobs, results)) for i in range(pool_size)]
    for p in pool:
        p.start()
    for i in range(1, 255):
        jobs.put(base_ip + '{0}'.format(i))
    for p in pool:
        jobs.put(None)
    try:
        analyzed = 0
        print("")
        s_time = datetime.now().strftime('%H:%M:%S')
        for p in pool:
            sys.stdout.write("\r[%s*%s] Scansione di rete avviata: %s >> "%(bright_yellow,end, s_time))
            analyzed += 1
            progress(analyzed, total=255)
            sys.stdout.flush()
            p.join()
    except KeyboardInterrupt:
        print("\n[%s-%s] Interrotto\n"%(red,end))
        final()
    while not results.empty():
        ip = results.get()
        ip_list.append(ip)
    print("")
    return ip_list

def scan(args):
    iface = netifaces.gateways()['default'][netifaces.AF_INET][1]
    try:
        localip = [l for l in ([ip for ip in socket.gethostbyname_ex(socket.gethostname())[2] if not ip.startswith("127.")][:1], [[(s.connect(('8.8.8.8', 53)), s.getsockname()[0], s.close()) for s in [socket.socket(socket.AF_INET, socket.SOCK_DGRAM)]][0][1]]) if l][0][0]
    except (socket.herror,socket.gaierror): # parrot os
        localip = netifaces.ifaddresses(str(iface))[netifaces.AF_INET][0]['addr']
    start_ = time.time()
    try:
        lst = map_network()
    except KeyboardInterrupt:
        print("\n[%s-%s] Interrotto\n"%(red,end))
        final()
    devices = []
    lst.sort() # ordina indirizzi ip
    for ip in lst:
        devices.append(ip)
        try:
            hostname = socket.gethostbyaddr(ip)[0]
        except socket.herror: # parrot os
            hostname = socket.getfqdn(ip)
            if hostname == ip:
                hostname = "( None )"
        pid = Popen(["arp", "-n", ip], stdout=PIPE)
        s = pid.communicate()[0]
        try:
            mac = re.search(r"(([a-f\d]{1,2}\:){5}[a-f\d]{1,2})", s).groups()[0]
        except AttributeError:
            pass
        if ip == localip:
            ip += " ( Locale )"
            mac = os.popen("ethtool -P %s"%(iface)).read().split()[2]
        print("")
        print("[%s+%s] IP       >> %s"%(bright_green,end, ip))
        print("[%s+%s] Hostname >> %s"%(bright_green,end, hostname))
        print("[%s+%s] MAC      >> %s"%(bright_green,end, mac))
    # "blacklisted"
    check_blacklisted = open("core/modules/lists/blacklist.txt","r").read()
    if len(check_blacklisted) != 0:
        in_blacklist = []
        blacklisted = []
        check_blacklisted = check_blacklisted.splitlines()
        for lines in check_blacklisted:
            line = lines.split()
            try:
                in_blacklist.append(line[0])
            except IndexError:
                pass
        for dev in devices:
            if dev in in_blacklist:
                blacklisted.append(dev)
        if len(blacklisted) != 0:
            if len(blacklisted) != 1:
                syntax = "i"
            else:
                syntax = "o"
            print("\n[%s!%s] Dispositiv%s in blacklist conness%s\n"%(red,end, syntax,syntax))
            for dev in blacklisted:
                try:
                    hostname = socket.gethostbyaddr(dev)[0]
                except socket.herror: # parrot os
                    hostname = socket.getfqdn(dev)
                    if hostname == dev:
                        hostname = ""
                print("[%s-%s] %s \t>> %s"%(red,end, dev, hostname))
    # -w option
    if args == "whitelist" or args == "blacklist":
        devices.sort()
        if len(devices) != 0:
            to_write = []
            for ip in devices:
                try:
                    hostname = socket.gethostbyaddr(ip)[0]
                except socket.herror: # parrot os
                    hostname = socket.getfqdn(ip)
                    if hostname == ip:
                        hostname = ""
                writer = ip + " > " + hostname
                to_write.append(writer)
                if len(to_write) != 0:
                    in_list = []
                    f = open("core/modules/lists/%s.txt"%(args), "r").read().split()
                    if ip in f:
                        pass
                    else:
                        os.system("echo '%s' >> core/modules/lists/%s.txt"%(writer, args))
            if len(devices) == 1:
                syntax = "o"
            else:
                syntax = "i"
            print("\n[%s+%s] Dispositiv%s aggiunt%s >> %s"%(bright_green,end, syntax,syntax, args))
        else:
            print("[%s-%s] Nessun dispositivo da aggiungere >> %s"%(bright_green,end, args))
    end_ = time.time()
    elapsed = round((end_-start_), 2)
    e_time = datetime.now().strftime('%H:%M:%S')
    print("")
    print("[%s*%s] Terminata >> %s"%(bright_yellow,end,e_time))
    print("[%s*%s] Connessi  >> %s"%(bright_yellow,end, len(devices)))
    print("[%s*%s] Durata    >> %s secondi\n"%(bright_yellow,end, elapsed))
    # portscan option
    if args == "portscan":
        from core.modules.scanning import portscan
        ip_amount = len(devices)
        if len(devices) != 0:
            s_time = datetime.now().strftime('%H:%M:%S')
            print("[%s*%s] Scansione porte avviata: %s\n"%(bright_yellow,end, s_time))
            ip_number = 1
            start_ = time.time()
            for ip in devices:
                portscan.portscan(ip,ip_number,ip_amount)
                ip_number += 1
            end_ = time.time()
            elapsed = round((end_-start_), 2)
            e_time = datetime.now().strftime('%H:%M:%S')
            print("[%s*%s] Scansione porte terminata: %s"%(bright_yellow,end, e_time))
            print("[%s*%s] Durata: %s secondi\n"%(bright_yellow,end, elapsed))
        else:
            print("[%s-%s] Nessun dispositivo connesso per la scansione porte"%(red,end))
        final()
