#!/usr/bin/python
# -*- coding: utf-8 -*-
import os

def start():
    os.system("echo 1 > /proc/sys/net/ipv4/ip_forward")

def stop():
    os.system("echo 0 > /proc/sys/net/ipv4/ip_forward")
