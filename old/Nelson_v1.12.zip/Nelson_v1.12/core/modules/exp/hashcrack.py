#!/usr/bin/python
# -*- coding: utf-8 -*-
import hashlib,sys,time,os

end = '\033[0m'
red = '\033[1;31m'
bright_green = '\033[1;32m'
bright_yellow = '\033[1;33m'

def final():
    import nelson as n
    n.main()

def get_algorithm(hash):
    if len(hash) == 32: return "md5"
    elif len(hash) == 40: return "sha1"
    elif len(hash) == 56: return "sha224"
    elif len(hash) == 64: return "sha256"
    elif len(hash) == 96: return "sha384"
    elif len(hash) == 128: return "sha512"
    else:
        print("[%s-%s] Hash non supportato o non valido"%(red,end))
        final()

def hash_checker(argument,hash):
    if hash == '' or hash == None:
        print("[%s-%s] Hash richiesto"%(red,end))
        final()
    if argument == "identify":
        message = "[%s*%s] Algoritmo       >> "%(bright_yellow,end)
        if len(hash) == 32: print(message+"md5")
        elif len(hash) == 40: print(message+"sha1")
        elif len(hash) == 56: print(message+"sha224")
        elif len(hash) == 64: print(message+"sha256")
        elif len(hash) == 96: print(message+"sha384")
        elif len(hash) == 128: print(message+"sha512")
        else:
            print("[%s-%s] Hash non supportato o non valido"%(red,end))
            final()
    if argument == "check":
        lengths = [32,40,56,64,96,128]
        if len(hash) not in lengths:
            print("[%s-%s] Hash non valido"%(red,end))
            final()

def progress(count, total):
    percents = round(100.0 * count / float(total), 1)
    sys.stdout.write('{}% '.format(percents))
    sys.stdout.flush()

def cracker(hash,wordlist):
    algorithm = get_algorithm(hash)
    if algorithm == "md5": h = hashlib.md5
    if algorithm == "sha1": h = hashlib.sha1
    if algorithm == "sha224": h = hashlib.sha224
    if algorithm == "sha256": h = hashlib.sha256
    if algorithm == "sha384": h = hashlib.sha384
    if algorithm == "sha512": h = hashlib.sha512
    try:
        print("\n[%s*%s] Avvio, attendere..."%(bright_yellow,end))
        w = open(wordlist, 'r').read().splitlines()
        amount = len(w)
        linecount = 0
        start = time.time()
        for word in w:
            crypt = h(word).hexdigest()
            linecount += 1
            sys.stdout.write("\r[%s*%s] Parole testate: %s/%s / Progresso > "%(bright_yellow,end, linecount, amount))
            sys.stdout.flush()
            progress(linecount,amount)
            if hash == crypt:
                stop = time.time()
                print("\n")
                print("[%s*%s] Tempo Trascorso >> %s secondi\n"%(bright_yellow,end, round((stop-start), 2)))
                hash_checker("identify",hash)
                print("[%s+%s] Hash            >> %s"%(bright_green,end, hash))
                print("[%s+%s] Testo Originale >> %s\n"%(bright_green,end, word))
                final()
        # se nessun risultato
        stop = time.time()
        print("\n")
        print("[%s-%s] Nessun Risultato"%(red,end))
        print("[%s*%s] Tempo Trascorso > %s secondi\n"%(bright_yellow,end, round((stop-start), 2)))
        final()
    except KeyboardInterrupt:
        print("\n\n[%s-%s] Interrotto\n"%(red,end))
        final()
