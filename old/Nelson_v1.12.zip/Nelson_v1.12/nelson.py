#!/usr/bin/python
# -*- coding: utf-8 -*-
import os,sys,time,readline,platform,socket,signal
from datetime import datetime

reload(sys)
sys.setdefaultencoding('utf8')

end = '\033[0m'
red = '\033[1;31m'
bright_green = '\033[1;32m'
bright_yellow = '\033[1;33m'

from core.modules.bin import installer as i
def installer(arg=None):
    if arg == "listsdir":
        i.CreateListsDir()
    else:
        i.install()

# Printers
def printerr(text):
    print("[%s-%s] %s"%(red,end,text))
def printinf(text):
    print("[%s*%s] %s"%(bright_yellow,end,text))
def printpls(text):
    print("[%s+%s] %s"%(bright_green,end,text))

try:
    import netifaces,requests
except ImportError:
    print("")
    printerr("Librerie mancanti, procedo con l'installazione\n")
    installer()

def handler(signum, frame):
    print(">> Ctrl+Z rilevato, arresto forzato")
signal.signal(signal.SIGTSTP, handler)

# bin
def helpers(type, arg=None):
    from core.modules.bin import helper
    if type == "logo":
        if arg == "logo_msg":
            helper.logo_msg()
        else:
            helper.logo()
    if type == "cmd":
        helper.cmd_help()
    if type == "edit":
        helper.edit_help()
    if type == "netscan":
         helper.netscan_help()
    if type == "hashcrack":
        helper.hashcrack_help()
    if type == "info":
        helper.info()
# scanning
def netscan(args):
    from core.modules.scanning import netscan
    netscan.scan(args)
def portscan(ip,ip_number,ip_amount):
    from core.modules.scanning import portscan
    portscan.portscan(ip,ip_number,ip_amount)
def bluescan():
    from core.modules.scanning import bluescan
    bluescan.scan()
# info
def whois(target):
    from core.modules.info import whois
    whois.whois(target)
def netinfo():
    from core.modules.info import netinfo
    try:
        netinfo.netinfo()
    except ValueError:
        printerr("Errore inaspettato")
def trace(target):
    from core.modules.info import trace
    trace.trace(target)
def getmac(ip):
    from core.modules.info import getmac
    getmac.getmac(ip)
# exp
def stresser(target,port):
    from core.modules.exp import nuker
    nuker.nuker(target,port)
def hashcrack(hash,wordlist):
    from core.modules.exp import hashcrack
    hashcrack.cracker(hash, wordlist)
def hashcrack_checker(argument,hash):
    from core.modules.exp import hashcrack
    hashcrack.hash_checker(argument,hash)
def wakeup(ip, mac):
    from core.modules.exp import wol
    wol.wakeup(ip, mac)
def netsniff(arg):
    from core.modules.exp.sniffer import sniffer
    if arg == "start":
        sniffer.control("start")
    if arg == "status":
        sniffer.control("status")
    if arg == "stop":
        sniffer.control("stop")
# spoofing
def macspoof(iface, mode, arg=None):
    from core.modules.spoofing import macspoof
    if mode == "spoof":
        macspoof.spoof(iface)
    if mode == "unspoof":
        macspoof.unspoof(iface)
    if mode == "check":
        if arg == "startup":
            macspoof.check(arg)
        else:
            macspoof.check()
    if mode == "status":
        macspoof.status()
def torghost(mode, arg=None, arg2=None):
    from core.modules.spoofing import torghost
    if arg == "check":
        if arg2 == "startup":
            torghost.check("startup")
        else:
            torghost.check()
    if arg == "status":
        torghost.status()
    else:
        torghost.control(mode)
#####
def exit_():
    print("\r  ")
    torghost(None, "check")
    macspoof(None, "check")
    if os.path.isfile("core/modules/__init__.pyc"):
        if os.path.isfile("core/__init__.pyc"):
            os.system("rm core/*.pyc")
        if os.path.isfile("core/modules/__init__.pyc"):
            os.system("rm core/modules/*.pyc")
        if os.path.isfile("core/modules/bin/__init__.pyc"):
            os.system("rm core/modules/bin/*.pyc")
        if os.path.isfile("core/modules/exp/__init__.pyc"):
            os.system("rm core/modules/exp/*.pyc")
        if os.path.isfile("core/modules/info/__init__.pyc"):
            os.system("rm core/modules/info/*.pyc")
        if os.path.isfile("core/modules/scanning/__init__.pyc"):
            os.system("rm core/modules/scanning/*.pyc")
        if os.path.isfile("core/modules/spoofing/__init__.pyc"):
            os.system("rm core/modules/spoofing/*.pyc")
    if os.path.isfile("nelson.pyc"):
        os.system("rm *.pyc")
    printerr("Fermato\n")
    sys.exit()
def check_conn():
    try:
        iface = netifaces.gateways()['default'][netifaces.AF_INET][1]
    except KeyError:
        printerr("Nessuna connessione")
        main()
    except KeyboardInterrupt:
        print("")
        printerr("Interrotto")
        main()

def main():
    from core.modules.bin import completer
    completer.normal()
    bash = u"\u250C"+3*u"\u2500"+"[ %sroot@%s ]"%(bright_green,os.getlogin()+end)+u"\u2500"+"[ %sNelson%s ]\n"%(bright_green,end)+u"\u2514"+u"\u2500"+u"\u257C"+" # "
    try:
        cmd_input = raw_input(bash)
    except (KeyboardInterrupt,RuntimeError):
        try:
            print(">> Premi nuovamente Ctrl+C per uscire")
            time.sleep(.6)
            return main()
        except KeyboardInterrupt:
            exit_()
    except EOFError:
        printerr("Usa 'quit','exit' o 'Ctrl+C' per uscire")
        return main()
    tokens = cmd_input.split()
    try:
        command = tokens[0]
    except IndexError:
        command = None
    try:
        option = tokens[1]
    except IndexError:
        option = None
    try:
        argument = tokens[2]
    except IndexError:
        argument = None
##### SHELL
    accepted = ["service","pwd","ftp","ssh","echo","ifconfig","ping","clear","reset","wget","git","apt","mkdir","rm","nano","sudo","touch","man","ls","dpkg","cat","mv","cp","ps","kill"]
    blocked = ["rm","mv","nano","echo"]
    if command in accepted:
        if command in blocked: # bloccati
            if "nelson.py" in cmd_input or "core" in cmd_input or "core/" in cmd_input:
                printerr("Comando bloccato, pensa a quello che fai")
                return main()
        print(" >> $ %s"%(cmd_input))
        os.system(cmd_input)
        return main()
##### CORE
    if command == "help" or command == "?":
        helpers("cmd")
        return main()
    elif command == "info":
        helpers("info")
        return main()
    elif command == "os":
        if option:
            cmd_input = cmd_input.replace("os ","")
            print(" >> $ %s"%(cmd_input))
            os.system(cmd_input)
        else:
            print(" >> $ os <comando>")
        return main()
    elif command == "edit":
        settings = ["whitelist","blacklist"]
        if option:
            if option not in settings:
                printerr("Parametro non valido")
                return main()
            if option == "whitelist" or option == "blacklist":
                os.system("nano core/modules/lists/%s.txt"%(option))
        else:
            helpers("edit")
        return main()
    elif command == "status":
        if os.path.isfile("core/modules/lists/whitelist.txt"):
            print("\n[#] Whitelist")
            show = open("core/modules/lists/whitelist.txt","r").read().splitlines()
            if len(show) == 0:
                printerr("Nessun elemento")
            else:
                for e in show:
                    printpls("%s"%(e))
        if os.path.isfile("core/modules/lists/blacklist.txt"):
            print("\n[#] Blacklist")
            show = open("core/modules/lists/blacklist.txt","r").read().splitlines()
            if len(show) == 0:
                printerr("Nessun elemento")
            else:
                for e in show:
                    printpls("%s"%(e))
        print("")
        macspoof(None, "status")
        print("")
        torghost(None, "status")
        print("")
        return main()
    elif command == "uninstall":
        if option:
            if option == "--yes":
                from core.modules.bin import installer
                installer.uninstall()
            else:
                printerr("")
        else:
            print("\n >> # Nelson verrà rimosso completamente dal tuo sistema")
            print(" >> # Potrai scaricarlo nuovamente dal seguente link:")
            print("    # https://www.github.com/Skull00/Nelson")
            print(" >> # Digita 'uninstall --yes' per procedere\n")
        return main()
    elif command == "quit" or command == "exit":
        exit_()
##### INFO
    elif command == "netinfo":
        check_conn()
        netinfo()
        return main()
    elif command == "whois":
        if option:
            check_conn()
            rpl = cmd_input.replace("whois ","").split()
            for e in rpl:
                whois(e)
            print("")
        else:
            print(" >> $ whois <target> [target2] [target3] ...")
        return main()
    elif command == "gethost":
        if option:
            check_conn()
            def gethost(target):
                try:
                    gethost = socket.gethostbyaddr(target)[0]
                except socket.herror:
                    gethost = socket.getfqdn(target) # parrot os
                except socket.gaierror:
                    printerr("%s \t>> ( Indirizzo non valido )"%(target))
                try:
                    if gethost == target:
                        printerr("%s \t>> -"%(target))
                    else:
                        printpls("%s \t>> %s"%(target, gethost))
                except UnboundLocalError:
                    pass
            targets = cmd_input.replace("gethost ","").split()
            for e in targets:
                gethost(e)
        else:
            print(" >> $ gethost <IP/indirizzo> [IP2/indirizzo2] [IP3/indirizzo3] ...")
        return main()
    elif command == "trace":
        if option:
            check_conn()
            trace(option)
        else:
            print(" >> $ trace <target>")
        return main()
##### SCANNING
    elif command == "netscan":
        check_conn()
        args = None
        if option:
            arg = ["-w","-p","-h","--help"]
            if option not in arg:
                printerr("Argomento non valido, 'netscan -h' per i comandi")
                return main()
            if option == "-h" or option == "--help":
                helpers("netscan")
                return main()
            if "-w" in cmd_input and "-p" in cmd_input:
                printerr("Argomenti 'write' e 'portscan' non possono collaborare")
                return main()
            if option == "-w":
                arg = ["whitelist","blacklist"]
                if argument:
                    if argument not in arg:
                        printerr("Lista non valida, 'netscan -h' per i comandi")
                        return main()
                    args = argument
                else:
                    printerr("Lista richiesta, 'netscan -h' per i comandi")
                    return main()
            elif option == "-p" or option == "--portscan":
                args = "portscan"
        else:
            print(" >> $ netscan -h > ulteriori comandi")
        netscan(args)
        return main()
    elif command == "bluescan":
        bluescan()
        return main()
    elif command == "portscan":
        if option:
            check_conn()
            targets = cmd_input.replace("portscan ","").split()
            s_time = datetime.now().strftime('%H:%M:%S')
            print("\n[%s*%s] Scansione porte avviata: %s\n"%(bright_yellow,end, s_time))
            ip_number = 1
            ip_amount = len(targets)
            start_ = time.time()
            for ip in targets:
                portscan(ip,ip_number,ip_amount)
                ip_number += 1
            end_ = time.time()
            elapsed = round((end_-start_), 2)
            e_time = datetime.now().strftime('%H:%M:%S')
            print("[%s*%s] Scansione porte terminata: %s"%(bright_yellow,end, e_time))
            print("[%s*%s] Durata: %s secondi\n"%(bright_yellow,end, elapsed))
        else:
            print(" >> $ portscan <target> [target2] [target3] ...")
        return main()
##### EXP
    elif command == "netsniff":
        check_conn()
        os.system("cd core/modules/exp/sniffer/ && python3 sniffer.py")
        os.system("cd core/modules/exp/sniffer/ && python pcredz.py -f capture.pcap -t -v > /dev/null &")
        os.system("clear && clear")
        print("")
        printinf("Possibili informazioni sensibili:\n")
        if os.path.isdir("core/output/sniffer") == False:
            os.system("mkdir core/output/sniffer")
        if os.path.isfile("core/modules/exp/sniffer/CredentialDump-Session.log"):
            os.system("mv core/modules/exp/sniffer/CredentialDump-Session.log core/output/sniffer/")
        existent = True
        if os.path.isfile("core/output/sniffer/CredentialDump-Session.log") == False:
            existent == False
            printerr("Nessuna informazione")
        if existent == True:
            os.system("cat core/output/sniffer/CredentialDump-Session.log")
        print("")
        return main()
    elif command == "nuker":
        if option:
            check_conn()
            target = option
            port = 80
            if argument:
                try:
                    port = int(argument)
                    if port < 1 or port > 65535:
                        printerr("Inserisci una porta tra 1 e 65535")
                        return main()
                except ValueError:
                    printerr("Porta non valida")
                    return main()
            stresser(target,port)
        else:
            print(" >> $ nuker <target> [port (default:80)]")
    	return main()
    elif command == 'hashcrack':
        hash = None
        if option:
            if option == "-i":
                if argument:
                    hash = argument
                    hashcrack_checker("identify",hash)
                else:
                    printerr("Hash richiesto")
                return main()
            hash = option
            hashcrack_checker("check",hash)
            if argument: # wordlist
                wordlist = argument
                if os.path.isfile(wordlist) == False:
                    printerr("File non trovato")
                    return main()
                hashcrack(hash, wordlist)
            else:
                printerr("Wordlist richiesta")
        else:
            helpers("hashcrack")
        return main()
    elif command == "macspoof":
        if option:
            options = ["start","stop","status"]
            if option not in options:
                printerr("Argomento non valido")
                return main()
            if option == "status":
                macspoof(None, "status")
                return main()
            if argument:
                if option == "start":
                    macspoof(argument, "spoof")
                if option == "stop":
                    macspoof(argument, "unspoof")
            else:
                printerr("Interfaccia richiesta")
        else:
            print(" >> $ macspoof <start/stop/status> [iface]")
        return main()
    elif command == "wakeup":
        if option:
            check_conn()
            mac = None
            if argument:
                mac = argument
                if len(mac) < 17:
                    printerr("Indirizzo MAC non valido")
                    return main()
            ip = option
            wakeup(ip, mac)
        else:
            print(" >> $ wakeup <target IP> [target MAC]")
        return main()
    elif command == "getmac":
        if option:
            check_conn()
            targets = cmd_input.replace("getmac ","").split()
            for e in targets:
                getmac(e)
        else:
            print(" >> $ getmac <target> [target2] [target3] ...")
        return main()
    elif command == "torghost":
        if option:
            options = ["start","switch","stop","status"]
            if option not in options:
                printerr("Argomento non valido")
                return main()
            if option == "status":
                torghost(None, "status")
                return main()
            else:
                check_conn()
                torghost(option)
        else:
            print(" >> $ torghost <start/switch/stop/status>")
        return main()
##### FINAL
    elif command == None:
        return main()
    else:
        printerr("Comando non valido: %s"%(cmd_input))
        return main()

def check_sys():
    systems = ["Kali","Parrot"]
    system = platform.linux_distribution()[0]
    if system not in systems:
        print("")
        printerr("Programma non compatibile col tuo sistema\n")
        init_exit()
def check_startup_conn():
    try:
        net_iface = netifaces.gateways()['default'][netifaces.AF_INET][1]
    except KeyError:
        print("")
        printerr("Nessuna interfaccia di rete rilevata")
        printerr("Senza connessione alcuni comandi sono bloccati")

if __name__ == "__main__":
    check_sys()
    if os.geteuid() != 0:
        print("[%s*%s] Permessi di root richiesti"%(bright_yellow,end))
        try: time.sleep(.5)
        except KeyboardInterrupt: sys.exit("")
        args = ['sudo', sys.executable] + sys.argv + [os.environ]
        os.execlpe('sudo', *args) # this line replaces the currently-running process with the sudo
    sys.stdout.write("\x1b]2; Nelson \x07") # Titolo terminale
    if os.path.isfile("/dev/rfkill"):
        os.system("rfkill unblock all")
    sys.stdout.write("\x1b[8;{rows};{cols}t".format(rows=24, cols=80))
    if os.path.isdir("core/modules/lists") == False:
        if os.path.isfile("core/modules/lists/whitelist.txt") == False or os.path.isfile("core/modules/lists/blacklist.txt") == False:
            installer("listsdir")
    if os.path.isfile("core/modules/output/installed") == False:
        print("")
        printinf("Installo pacchetti\n")
        installer()
    helpers("logo")
    check_startup_conn()
    torghost(None, "check", "startup")
    macspoof(None, "check", "startup")
    print("")
    helpers("logo","logo_msg")
    print("")
    main()
