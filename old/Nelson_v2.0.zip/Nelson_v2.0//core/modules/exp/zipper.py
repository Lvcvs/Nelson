#!/usr/bin/python
# -*- coding: utf-8 -*-
import sys
import time
import zipfile
import itertools
from datetime import datetime

end = '\033[0m'
red = '\033[1;31m'
bright_green = '\033[1;32m'
bright_yellow = '\033[1;33m'

def final():
    import nelson as n
    n.main()

def crack(filename,choice):
    characters = "abcdefghijklmnopqrstuvwxyz"
    if choice == 1:
        characters = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
    if choice == 2:
        characters = "0123456789"
    if choice == 3:
        characters = "abcdefghijklmnopqrstuvwxyz1234567890"
    if choice == 4:
        characters = "ABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890"
    if choice == 5:
        characters = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ"
    if choice == 6:
        characters = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890"
    if choice == 7:
        characters = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789.#@+-_*/=%?!<>"

    if ".zip" not in filename:
        print("[%s-%s] Archivio non valido"%(red,end))
        final()
    try:
        zipFile = zipfile.ZipFile(filename, "r")
    except IOError:
        print("[%s-%s] File non trovato"%(red,end))
        final()

    print("\n[#] Zipper\n")
    print("[#] File: %s"%(filename))
    print("[#] Sequenza: %s\n"%(choice))

    s_time = datetime.now().strftime('%H:%M:%S')
    start_ = time.time() # avvio

    print("[%s+%s] Cracking avviato: %s"%(bright_green,end, s_time))

    tested = 0
    psw_found = False
    for leng in range(1, len(characters)+1):
        if psw_found == True:
            break

        it = itertools.product(characters, repeat=leng)

        for passw in it:
            tested += 1
            sys.stdout.write("\r[%s*%s] Lunghezza Password / Testate: %s / %s"%(bright_yellow,end, leng, tested))
            sys.stdout.flush()
            try:
                passwd = "".join(passw)
                zipFile.setpassword(passwd)
                zipFile.extractall()

                # se la password è corretta
                psw_found = True
                break
            except RuntimeError: # password sbagliata
                pass
            except zipfile.BadZipfile:
                pass
            except KeyboardInterrupt:
                print("\n\n[%s-%s] Interrotto\n"%(red,end))
                final()
            except:
                pass

    end_ = time.time() # termine
    elapsed = round((end_-start_), 2)
    e_time = datetime.now().strftime('%H:%M:%S')

    print("\n\n[%s+%s] Terminato: %s"%(bright_green,end, e_time))
    print("[%s*%s] Durata: %s secondi\n"%(bright_yellow,end, elapsed))


    if psw_found == True:
        print("[%s+%s] Password Trovata: %s\n"%(bright_green,end, passwd))
    else:
        print("[%s-%s] Nessuna Password Trovata\n"%(red,end))
